import './Header.css'
import NavBar from '../NavBar/NavBar';

const Header = () => (
    <>
    <h3><NavBar /></h3></>
)

export default Header