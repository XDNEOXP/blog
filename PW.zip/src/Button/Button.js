import './Button.css'

const Button = ({children, handelClick = () => {}}) => (
     <button onClick={handelClick} className="btn">{children}</button>
    )

export default Button