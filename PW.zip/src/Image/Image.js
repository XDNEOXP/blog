const Image = ({imgSrc}) => <img src={imgSrc} />

export default Image