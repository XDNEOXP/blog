const About = () => (
    <div className="Content">
        <h4>Hi, I’m Neo. Nice to meet you.</h4>
        <p>I'm a backend developer and i started to learn react js and i'm so excited.</p>
    </div>
)

export default About