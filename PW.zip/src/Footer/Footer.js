import './Footer.css'

const Footer = () => (
    <div className="Footer">
        <h5>Developed By Neo</h5>
    </div>
)

export default Footer